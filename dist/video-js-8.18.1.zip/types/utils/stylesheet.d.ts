export function createStyleElement(className: string): Element;
export function setTextContent(el: Element, content: string): void;
//# sourceMappingURL=stylesheet.d.ts.map